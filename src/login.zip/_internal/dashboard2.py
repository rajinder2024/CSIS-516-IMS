import os
import shutil
import tkinter as tk
from tkinter import ttk, messagebox, PhotoImage
from PIL import Image, ImageTk
import sqlite3
import time
import datetime
from employee import employeeClass
from supplier import supplierClass
from category import categoryClass
from product import productClass
from stock_report import StockReportClass
from sales_report import SalesReportClass
from sales import salesClass
from sales_forecast import SalesForecastClass
import subprocess
from utils import resource_path
from typing import Optional, Union, Literal

class IMS:
    def __init__(self, root: tk.Tk, user_id: int, user_type: str):
        self.root = root
        self.user_id = user_id
        self.user_type = user_type
        
        # Initialize image attributes with type hints
        self.icon_title: Optional[PhotoImage] = None
        self.MenuLogo: Optional[ImageTk.PhotoImage] = None
        self.icon_side: Optional[PhotoImage] = None
        self.ReportLogo: Optional[ImageTk.PhotoImage] = None
        self.icon_sales: Optional[ImageTk.PhotoImage] = None
        self.icon_stock: Optional[ImageTk.PhotoImage] = None
        self.icon_activity: Optional[ImageTk.PhotoImage] = None

        self.setup_ui()

    def setup_ui(self):
        """Setup the main user interface"""
        self.root.geometry("1350x700+0+0")
        self.root.title("Inventory Management System")
        self.root.config(bg="white")
        
        # Load images with error handling
        self.load_images()
        
        # Create title bar
        self.create_title_bar()
        
        # Create left menu
        self.create_left_menu()
        
        # Create dashboard widgets
        self.create_dashboard_widgets()
        
        # Create right menu
        self.create_right_menu()
        
        # Create footer
        self.create_footer()
        
        # Start content updates
        self.update_content()

    def load_images(self):
        """Load all images with proper error handling"""
        try:
            self.icon_title = PhotoImage(file=resource_path("images/logo1.png"))
        except Exception as e:
            print(f"Error loading title icon: {e}")

        try:
            menu_img = Image.open(resource_path("images/menu_im.png"))
            menu_img = menu_img.resize((200, 200), Image.Resampling.LANCZOS)
            self.MenuLogo = ImageTk.PhotoImage(menu_img)
        except Exception as e:
            print(f"Error loading menu logo: {e}")

        try:
            self.icon_side = PhotoImage(file=resource_path("images/side.png"))
        except Exception as e:
            print(f"Error loading side icon: {e}")

        try:
            report_img = Image.open(resource_path("images/report.png"))
            report_img = report_img.resize((200, 200), Image.Resampling.LANCZOS)
            self.ReportLogo = ImageTk.PhotoImage(report_img)
        except Exception as e:
            print(f"Error loading report logo: {e}")

        try:
            sales_img = Image.open(resource_path("images/sales_icon.png"))
            sales_img = sales_img.resize((25, 25), Image.Resampling.LANCZOS)
            self.icon_sales = ImageTk.PhotoImage(sales_img)
        except Exception as e:
            print(f"Error loading sales icon: {e}")

        try:
            stock_img = Image.open(resource_path("images/stock_icon.png"))
            stock_img = stock_img.resize((25, 25), Image.Resampling.LANCZOS)
            self.icon_stock = ImageTk.PhotoImage(stock_img)
        except Exception as e:
            print(f"Error loading stock icon: {e}")

        try:
            activity_img = Image.open(resource_path("images/activity_icon.png"))
            activity_img = activity_img.resize((25, 25), Image.Resampling.LANCZOS)
            self.icon_activity = ImageTk.PhotoImage(activity_img)
        except Exception as e:
            print(f"Error loading activity icon: {e}")

    def create_title_bar(self):
        """Create the title bar with logo"""
        title = tk.Label(
            self.root,
            text="Inventory Management System",
           # image=self.icon_title if self.icon_title else None,
            compound=tk.RIGHT,
            font=("times new roman", 40, "bold"),
            bg="#010c48",
            fg="white",
            anchor="w",
            padx=20,
        )
        title.place(x=0, y=0, relwidth=1, height=70)

        btn_logout = tk.Button(
            self.root,
            text="Logout",
            command=self.logout,
            font=("times new roman", 15, "bold"),
            bg="red",
            cursor="hand2"
        )
        btn_logout.place(x=1150, y=10, height=50, width=150)

        self.lbl_clock = tk.Label(
            self.root,
            text=f"Welcome User ID: {self.user_id} ({self.user_type})\t\t Date: MM-DD-YYYY\t\t Time: HH:MM:SS",
            font=("times new roman", 15),
            bg="#010c48",
            fg="white"
        )
        self.lbl_clock.place(x=0, y=70, relwidth=1, height=30)

    def create_left_menu(self):
        """Create the left-side menu"""
        LeftMenu = tk.Frame(self.root, bd=2, relief=tk.RIDGE, bg="white")
        LeftMenu.place(x=0, y=102, width=200, height=565)

        if self.MenuLogo:
            lbl_menulogo = tk.Label(LeftMenu, image=self.MenuLogo)
            lbl_menulogo.pack(side=tk.TOP, fill=tk.X)

        tk.Label(
            LeftMenu,
            text="Menu",
            font=("times new roman", 20),
            bg="#009698"
        ).pack(side=tk.TOP, fill=tk.X)

        menu_items = [
            ("Employee", self.employee),
            ("Supplier", self.supplier),
            ("Category", self.category),
            ("Product", self.product),
            ("Sales", self.sales),
            ("Exit", self.exit)
        ]

        for text, command in menu_items:
            btn = tk.Button(
                LeftMenu,
                text=text,
                command=command,
               # image=self.icon_side if self.icon_side else None,
                compound=tk.LEFT,
                padx=5,
                anchor="w",
                font=("times new roman", 20),
                bg="white",
                bd=3,
                cursor="hand2"
            )
            btn.pack(side=tk.TOP, fill=tk.X)

    def create_dashboard_widgets(self):
        """Create dashboard counter widgets"""
        self.lbl_employee = self.create_counter_label(
            "Total Employee\n[0]", "#33bbf9", 230, 120
        )
        self.lbl_supplier = self.create_counter_label(
            "Total Supplier\n[0]", "#ff5722", 540, 120
        )
        self.lbl_category = self.create_counter_label(
            "Total Category\n[0]", "#009688", 850, 120
        )
        self.lbl_product = self.create_counter_label(
            "Total Product\n[0]", "#607d8b", 230, 300
        )
        self.lbl_sales = self.create_counter_label(
            "Total Sales\n[0]", "#3f51b5", 540, 300
        )

    def create_counter_label(self, text: str, bg_color: str, x: int, y: int) -> tk.Label:
        """Helper to create consistent counter labels"""
        lbl = tk.Label(
            self.root,
            text=text,
            bd=5,
            relief=tk.RIDGE,
            bg=bg_color,
            fg="white",
            font=("goudy old style", 20, "bold")
        )
        lbl.place(x=x, y=y, height=150, width=270)
        return lbl

    def create_right_menu(self):
        """Create the right-side reports menu"""
        RightMenu = tk.Frame(self.root, bd=3, relief=tk.GROOVE, bg="white", highlightthickness=1)
        RightMenu.place(x=1150, y=102, width=200, height=565)

        if self.ReportLogo:
            lbl_rightlogo = tk.Label(RightMenu, image=self.ReportLogo, bg="white")
            lbl_rightlogo.pack(side=tk.TOP, fill=tk.X)

        tk.Label(
            RightMenu,
            text="Reports",
            font=("times new roman", 20),
            bg="#009698"
        ).pack(side=tk.TOP, fill=tk.X)

        report_items = [
            ("Sales Report", self.sales_report, self.icon_sales),
            ("Stock Report", self.stock_report, self.icon_stock),
            ("Sales Forecast", self.forecast, self.icon_activity)
        ]

        for text, command, icon in report_items:
            btn = tk.Button(
                RightMenu,
                text=text,
                command=command,
                #image=icon if icon else None,
                compound=tk.LEFT,
                anchor="w",
                font=("times new roman", 20),
                bg="white",
                bd=3,
                cursor="hand2",
                padx=10
            )
            btn.pack(side=tk.TOP, fill=tk.X, pady=5)

    def create_footer(self):
        """Create the footer"""
        tk.Label(
            self.root,
            text="Inventory Management System | Developed by Rajinder | © 2025",
            font=("times new roman", 15),
            bg="#4d636d",
            fg="white"
        ).pack(side=tk.BOTTOM, fill=tk.X)

    def update_content(self):
        """Update dashboard content"""
        if not self.root.winfo_exists():  # Check if window still exists
            return

        try:
            con = sqlite3.connect(resource_path("ims.db"))
            cur = con.cursor()

            # Get counts from database
            counts = {
                'product': len(cur.execute("SELECT * FROM product").fetchall()),
                'supplier': len(cur.execute("SELECT * FROM supplier").fetchall()),
                'category': len(cur.execute("SELECT * FROM category").fetchall()),
                'employee': len(cur.execute("SELECT * FROM employee").fetchall())
            }

            # Update labels
            self.lbl_employee.config(text=f'Total Employee\n[{counts["employee"]}]')
            self.lbl_supplier.config(text=f'Total Supplier\n[{counts["supplier"]}]')
            self.lbl_category.config(text=f'Total Category\n[{counts["category"]}]')
            self.lbl_product.config(text=f'Total Product\n[{counts["product"]}]')

            # Get sales count
            try:
                bill_dir = resource_path("bill")
                bill_count = len(os.listdir(bill_dir))
                self.lbl_sales.config(text=f'Total Sales\n[{bill_count}]')
            except Exception as e:
                print(f"Error counting bills: {e}")
                self.lbl_sales.config(text='Total Sales\n[Error]')

            # Update clock
            time_str = time.strftime("%H:%M:%S")
            date_str = time.strftime("%m-%d-%Y")
            self.lbl_clock.config(
                text=f"Welcome User ID: {self.user_id} ({self.user_type})\t\t Date: {date_str}\t\t Time: {time_str}"
            )

            # Schedule next update
            self.lbl_clock.after(2000, self.update_content)

        except Exception as ex:
            error_msg = f"Error in update_content: {str(ex)}"
            print(error_msg)
            with open("error_log.txt", "a") as f:
                f.write(f"{datetime.datetime.now()}: {error_msg}\n")
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    # Menu action methods
    def employee(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = employeeClass(self.new_win)

    def supplier(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = supplierClass(self.new_win)

    def category(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = categoryClass(self.new_win)

    def product(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = productClass(self.new_win)

    def sales(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = salesClass(self.new_win)

    def sales_report(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = SalesReportClass(self.new_win)

    def stock_report(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = StockReportClass(self.new_win)

    def forecast(self):
        self.new_win = tk.Toplevel(self.root)
        self.new_obj = SalesForecastClass(self.new_win)

    def exit(self):
        confirm = messagebox.askyesno("Confirm Exit", "Are you sure you want to exit?", parent=self.root)
        if confirm:
            self.root.destroy()

    def logout(self):
        self.root.destroy()
        os.system("python login.py")

if __name__ == "__main__":
    import sys
    root = tk.Tk()
    
    # Default values
    user_id = 0
    user_type = "Admin"
    
    # Check for command line arguments
    if len(sys.argv) > 2:
        try:
            user_id = int(sys.argv[1])
            user_type = sys.argv[2]
        except (ValueError, IndexError):
            pass
    
    # Set working directory for compiled apps
    if getattr(sys, 'frozen', False):
        os.chdir(os.path.dirname(sys.executable))
    
    # Create and run application
    app = IMS(root, user_id, user_type)
    root.mainloop()