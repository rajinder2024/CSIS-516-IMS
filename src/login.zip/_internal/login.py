import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import subprocess
import hashlib
import os
import sys
import glob
import atexit
import shutil
import tempfile
import ctypes
from utils import resource_path
#import billing2
#import dashboard2

class SimpleLogin:
    def __init__(self, root):
        self.root = root
        self.db_path = resource_path('ims.db')
        
        # Verify database before proceeding
        if not self.verify_database():
            messagebox.showerror("Error", "Database validation failed. Application will exit.")
            sys.exit(1)
            
        self.setup_window()
        self.create_widgets()
        self.configure_styles()
        self.setup_cleanup()

    def setup_cleanup(self):
        """Setup console hiding and cleanup handlers for EXE"""
        if getattr(sys, 'frozen', False):
            # Hide console window in compiled EXE
            kernel32 = ctypes.WinDLL('kernel32')
            user32 = ctypes.WinDLL('user32')
            if kernel32 and user32:
                hwnd = kernel32.GetConsoleWindow()
                if hwnd:
                    user32.ShowWindow(hwnd, 0)
        
        # Register temp file cleanup
        atexit.register(self.cleanup_temp_files)

    def cleanup_temp_files(self):
        """Clean up temporary files created by PyInstaller"""
        try:
            if getattr(sys, 'frozen', False):
                temp_dir = os.path.join(tempfile.gettempdir(), '_MEI*')
                for dir_path in glob.glob(temp_dir):
                    if os.path.isdir(dir_path):
                        shutil.rmtree(dir_path, ignore_errors=True)
        except Exception:
            pass

    def verify_database(self):
        """Verify database structure integrity"""
        try:
            if not os.path.exists(self.db_path):
                messagebox.showerror("Error", f"Database file not found at:\n{self.db_path}")
                return False

            con = sqlite3.connect(self.db_path)
            cur = con.cursor()
            
            # Check required tables exist
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='employee'")
            if not cur.fetchone():
                messagebox.showerror("Error", "Required 'employee' table missing in database")
                return False
                
            # Verify table structure
            cur.execute("PRAGMA table_info(employee)")
            columns = {col[1] for col in cur.fetchall()}
            required_columns = {'eid', 'email', 'pass', 'utype'}
            if not required_columns.issubset(columns):
                messagebox.showerror("Error", 
                    f"Employee table missing required columns.\nFound: {columns}\nRequired: {required_columns}")
                return False
                
            return True
            
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Cannot access database:\n{str(e)}")
            return False
        finally:
            if 'con' in locals():
                con.close()  # type: ignore

    def setup_window(self):
        """Configure main window properties"""
        self.root.title("Inventory Management System - Login")
        self.root.geometry("400x500")
        self.root.resizable(False, False)
        self.root.configure(bg="#f5f5f5")
        
        # Center window on screen
        window_width = 400
        window_height = 500
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width // 2) - (window_width // 2)
        y = (screen_height // 2) - (window_height // 2)
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")

    def create_widgets(self):
        """Create all GUI widgets"""
        # Main container
        main_frame = tk.Frame(self.root, bg="#ffffff", padx=30, pady=40)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_frame, bg="#ffffff")
        header_frame.pack(fill=tk.X, pady=(0, 30))
        
        tk.Label(
            header_frame,
            text="INVENTORY SYSTEM",
            font=("Helvetica", 16, "bold"),
            bg="#ffffff",
            fg="#333333"
        ).pack(pady=(0, 5))
        
        tk.Label(
            header_frame,
            text="Please sign in to continue",
            font=("Helvetica", 10),
            bg="#ffffff",
            fg="#666666"
        ).pack()
        
        # Form fields
        form_frame = tk.Frame(main_frame, bg="#ffffff")
        form_frame.pack(fill=tk.X)
        
        # Employee ID/Email
        tk.Label(
            form_frame,
            text="Employee ID/Email",
            font=("Helvetica", 9),
            bg="#ffffff",
            fg="#444444",
            anchor="w"
        ).pack(fill=tk.X, pady=(10, 0))
        
        self.username_entry = ttk.Entry(
            form_frame,
            font=("Helvetica", 11)
        )
        self.username_entry.pack(fill=tk.X, pady=(5, 15), ipady=5)
        
        # Password
        tk.Label(
            form_frame,
            text="Password",
            font=("Helvetica", 9),
            bg="#ffffff",
            fg="#444444",
            anchor="w"
        ).pack(fill=tk.X, pady=(5, 0))
        
        self.password_entry = ttk.Entry(
            form_frame,
            font=("Helvetica", 11),
            show="•"
        )
        self.password_entry.pack(fill=tk.X, pady=(5, 20), ipady=5)
        
        # Login button
        self.login_btn = ttk.Button(
            form_frame,
            text="SIGN IN",
            command=self.authenticate,
            style="Accent.TButton"
        )
        self.login_btn.pack(fill=tk.X, ipady=8, pady=(10, 0))
        
        # Footer
        footer_frame = tk.Frame(main_frame, bg="#ffffff")
        footer_frame.pack(fill=tk.X, pady=(20, 0))
        
        tk.Label(
            footer_frame,
            text="© 2025 Inventory System",
            font=("Helvetica", 8),
            fg="#999999",
            bg="#ffffff"
        ).pack(side=tk.BOTTOM)
        
        # Set focus and bind Enter key
        self.username_entry.focus()
        self.root.bind("<Return>", lambda e: self.authenticate())

    def configure_styles(self):
        """Configure ttk widget styles"""
        style = ttk.Style()
        style.theme_use("clam")
        
        style.configure("TEntry",
            foreground="#333333",
            fieldbackground="#ffffff",
            bordercolor="#dddddd",
            padding=5,
            relief="flat")
        
        style.configure("Accent.TButton",
            foreground="white",
            background="#4e73df",
            font=("Helvetica", 10, "bold"),
            borderwidth=0,
            padding=10)
        
        style.map("Accent.TButton",
            background=[("active", "#3a5cbf"), ("disabled", "#cccccc")],
            foreground=[("disabled", "#999999")])

    def authenticate(self):
        """Handle user authentication"""
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        
        if not username or not password:
            messagebox.showerror("Error", "All fields are required", parent=self.root)
            return

        try:
            con = sqlite3.connect(self.db_path)
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            
            # Query by ID or email
            if username.isdigit():
                cur.execute("SELECT * FROM employee WHERE eid=?", (int(username),))
            else:
                cur.execute("SELECT * FROM employee WHERE LOWER(email)=LOWER(?)", (username,))
            
            user = cur.fetchone()
            
            if user:
                stored_password = user['pass']
                
                # Verify password (plaintext or hashed)
                if stored_password == password or stored_password == self.hash_password(password):
                    self.launch_dashboard(user)
                else:
                    messagebox.showerror("Error", "Invalid credentials", parent=self.root)
            else:
                messagebox.showerror("Error", "User not found", parent=self.root)
                
        except Exception as ex:
            messagebox.showerror("Error", f"Authentication failed: {str(ex)}", parent=self.root)
        finally:
            if 'con' in locals():
                con.close() # type: ignore

    def launch_dashboard(self, user):
    
        self.root.destroy()
        try:
            if getattr(sys, 'frozen', False):
                exe_name = "dashboard2.exe" if user['utype'].lower() == "admin" else "billing2.exe"
                exe_path = os.path.join(os.path.dirname(sys.executable), exe_name)
                print("Launching EXE:", exe_path)
                subprocess.Popen([exe_path, str(user['eid']), user['utype']])
            else:
                script = "dashboard2.py" if user['utype'].lower() == "admin" else "billing2.py"
                print("Launching Script:", script)
                subprocess.Popen([sys.executable, script, str(user['eid']), user['utype']])
        except Exception as e:
            print("Error launching dashboard:", e)


    def hash_password(self, password):
        """Simple SHA-256 password hashing"""
        return hashlib.sha256(password.encode()).hexdigest()

if __name__ == "__main__":
    # Set working directory for EXE
    if getattr(sys, 'frozen', False):
        os.chdir(os.path.dirname(sys.executable))
    
    root = tk.Tk()
    app = SimpleLogin(root)
    root.mainloop()
    